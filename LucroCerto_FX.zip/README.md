# 💰 LucroCerto FX

Sistema automatizado com IA para alta precisão em Forex.

## Como rodar localmente:
1. Instale as dependências:
   ```bash
   pip install -r requirements.txt
   ```
2. Rode o projeto:
   ```bash
   streamlit run main.py
   ```

## Como rodar no Streamlit Cloud:
- Envie estes arquivos para um repositório no GitHub.
- No [Streamlit Cloud](https://streamlit.io/cloud), conecte seu repositório e publique.
